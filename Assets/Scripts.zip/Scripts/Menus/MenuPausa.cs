using UnityEngine;
using UnityEngine.UI; // �Importante para manejar im�genes!

public class MenuPausa : MonoBehaviour
{
    public GameObject panelPausaUI;
    public GameObject botonMusica; // Arrastra aqu� el bot�n de m�sica
    public Image imagenBotonMusica; // Arrastra aqu� el componente Image del bot�n m�sica

    public Sprite iconoMusicaOn;  // Sprite de m�sica normal
    public Sprite iconoMusicaOff; // Sprite de m�sica tachada

    private bool musicaActiva = true;

    // 1. Funci�n para mostrar/ocultar el bot�n de m�sica
    public void ToggleVisibilidadMusica()
    {
        // Si est� activo lo oculta, si est� oculto lo muestra
        botonMusica.SetActive(!botonMusica.activeSelf);
    }

    // 2. Funci�n para cambiar el estado de la m�sica (On/Off)
    public void CambiarEstadoMusica()
    {
        musicaActiva = !musicaActiva;

        if (musicaActiva)
        {
            imagenBotonMusica.sprite = iconoMusicaOn;
            // Aqu� en un futuro pondr�s: MiFuenteDeAudio.Play();
            AudioListener.volume = 1f; // Esto activa todo el sonido de Unity
            Debug.Log("M�sica Activada");
        }
        else
        {
            imagenBotonMusica.sprite = iconoMusicaOff;
            // Aqu� en un futuro pondr�s: MiFuenteDeAudio.Pause();
            AudioListener.volume = 0f; // Esto silencia TODO el juego de golpe
            Debug.Log("M�sica Silenciada");
        }
    }

    // ... tus otras funciones de Pausar() y Reanudar()
}
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SkillNode : MonoBehaviour
{
    [Header("Mis Datos")]
    public SkillData myData; // Arrastras el ScriptableObject aqu� en el Inspector

    [Header("Mi UI")]
    public Image iconImage;
    public TextMeshProUGUI costText;
    public Button buyButton;
    public LineRenderer lineRenderer;

    [Header("Ajustes Visuales del �rbol")]
    private Color colorLocked = Color.red;
    private Color colorUnlocked = new Color(0.4f, 0.8f, 0.2f, 1f);
    void Start()
    {
        // Al arrancar, el bot�n se disfraza con los datos del ScriptableObject
        iconImage.sprite = myData.icon;
        costText.text = myData.baseCost.ToString() + " XP";
        if (buyButton != null)
        {
            buyButton.onClick.AddListener(OnClick);
        }
    }

    public void OnClick()
    {
        // Le pasamos nuestro ScriptableObject al Manager para que �l haga los c�lculos
        FindObjectOfType<SkillTreeManager>().TryBuySkill(myData);
    }

    /// <summary>
    /// El Manager llama a esto para decirle al bot�n c�mo tiene que verse.
    /// </summary>
    public void RefreshVisuals(bool isUnlocked)
    {
        if (!isUnlocked)
        {
            // ESTADO 1: NO SE PUEDE COMPRAR
            if (buyButton != null) buyButton.interactable = false; // No se puede clickear
            if (costText != null) costText.text = "";
            iconImage.color = new Color(255f, 255f, 255f, 100f);
            // Ponemos la l�nea "bloqueada"
            if (lineRenderer != null)
            {
                lineRenderer.startColor = colorLocked;
                lineRenderer.endColor = colorLocked;
            }
        }
        else
        {
            // ESTADO 2: NO LO TENEMOS, PERO PODEMOS COMPRARLO
            if (buyButton != null) buyButton.interactable = true; // Se puede clickear
            if (costText != null) costText.text = myData.baseCost.ToString() + " xp";
            iconImage.color = new Color(255f, 255f, 255f, 255f);
            // Ponemos la l�nea "desbloqueada"
            if (lineRenderer != null)
            {
                lineRenderer.startColor = colorUnlocked;
                lineRenderer.endColor = colorUnlocked;
            }
        }
    }

}

using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Gestiona la detección de objetivos mediante un radio configurable y dispara.
/// También controla la lógica de construcción al hacer clic sobre la casilla vacía.
/// </summary>
public class Tower : MonoBehaviour
{
    [Header("Referencias y Config")]
    public TowerData config;
    public List<GameObject> towerImagen;
    public LineRenderer lineRenderer;
    [Header("Botones Interfaz")]
    public GameObject deleteTowerGameObject;
    public GameObject updateTowerGameObject;
    // Variables de Estado
    private float laserActiveTimer;    // Contador para los 5s
    private float laserRestTimer;      // Contador para los 2s
    private float currentRestDuration; // Cuánto dura el descanso (se reduce al mejorar)
    private bool isOverheated = false;
    private float damageAccrued = 0f;
    private GameObject projectilePrefab; // Se llena en el Start
    private float fireCooldown;          // Tiempo entre balas
    private float fireTimer = 0f;

    [HideInInspector] public float attackRadius;
    [HideInInspector] public float currentDamage;
    [HideInInspector] public float upgradeDamageStep;
    [HideInInspector] public float upgradeCooldownStep;
    [HideInInspector] public int totalGoldInvested = 0;
    [HideInInspector] public bool isBuilt = false;
    [HideInInspector] public float currentIncreaseDamage;
    private List<Tower> buffedTowers = new List<Tower>();

    private Transform currentTarget;
    private SpriteRenderer spriteRenderer;
    private DeleteTower deletetower;
    private UpdateTower updatetower;
    private GameManager gameManager;
    private ConstructionMenu constructionMenu;
    public static GameObject gameObjectUpdateDeleteTower;
    public static Tower towerActiveInMenu;
    int circleSegments = 50;
    private void Awake() => towerActiveInMenu = null;

    public ShortCutScript shortCuts;
    /// <summary>
    /// Inicializa las referencias de los componentes, busca el menú global en la escena 
    /// y autoconstruye la torre base basándose en la elección del jugador en el menú de construcción.
    /// </summary>
    private void Start()
    {
        spriteRenderer = this.GetComponent<SpriteRenderer>();
        deletetower = this.GetComponentInChildren<DeleteTower>(true);
        updatetower = this.GetComponentInChildren<UpdateTower>(true);
        gameManager = FindAnyObjectByType<GameManager>();
        gameObjectUpdateDeleteTower = GameObject.Find("gameObjectUpdateDeleteTower");
        constructionMenu = FindAnyObjectByType<ConstructionMenu>();

        if (config != null)
        {
            float treeIncreaseDamage = GameManager.metaProgression.upgradesTree[config.nameOfTower][0];
            float treeIncreaseRadius = GameManager.metaProgression.upgradesTree[config.nameOfTower][1];
            float treeIncreaseVelocity = GameManager.metaProgression.upgradesTree[config.nameOfTower][2];
            attackRadius = config.baseAttackRadius * treeIncreaseRadius;
            upgradeDamageStep = config.damageUpgradeAmount * treeIncreaseDamage;
            upgradeCooldownStep = config.cooldownUpgradeAmount / treeIncreaseVelocity;

            // CARGA SEGÚN EL TIPO DE DATA
            if (config is LaserTowerData laserData)
            {
                currentDamage = laserData.damagePerSecond * treeIncreaseDamage;
                laserActiveTimer = laserData.onTime / treeIncreaseVelocity;
                currentRestDuration = laserData.offTime;
            }
            else if (config is ProjectileTowerData projData)
            {
                currentDamage = projData.baseDamage * treeIncreaseDamage;
                fireCooldown = projData.baseFireRate / treeIncreaseVelocity;
                projectilePrefab = projData.projectilePrefab;
            }
            else if (config is SupportTowerData supportData)
            {
                currentIncreaseDamage = supportData.baseIncreaseDamage * treeIncreaseDamage;
                fireCooldown = supportData.baseFireRate / treeIncreaseVelocity;
            }
        }
        SetTower(null, null, constructionMenu.flagTypeTower);
    }
    /// <summary>
    /// Se ejecuta frame a frame y controla el ciclo de vida de la torre:
    /// 1. Comprueba si el jugador ha solicitado una mejora (cambiando sprites y niveles).
    /// 2. Comprueba si el jugador ha vendido la torre (restaurando la casilla y devolviendo oro).
    /// 3. Si la torre está construida y activa, busca enemigos y gestiona el temporizador para disparar.
    /// </summary>
    private void Update()
    {
        if (updatetower && updatetower.needUpdateTower && updatetower.typeOfTower != -1)
        {
            int nextLevel = updatetower.levelOfTower + 1;
            // Cogemos el sprite del nivel al que acabamos de subir (1 o 2)
            SpriteRenderer nexSprite = towerImagen[nextLevel].GetComponent<SpriteRenderer>();
            BoxCollider2D nexCol = towerImagen[nextLevel].GetComponent<BoxCollider2D>();

            SetTower(nexSprite, nexCol, updatetower.typeOfTower);

            updatetower.needUpdateTower = false; // Reset de la bandera

            return; // Salimos del frame para evitar conflictos

        }
        if (deletetower && deletetower.isDeleteTower)
        {
            int goldRecovered = Mathf.RoundToInt(totalGoldInvested * 0.75f);
            GameManager.countMoney += goldRecovered;
            GameManager.ShowFloatingMoney(goldRecovered, isGain: true);
            GameManager.sound(GameManager.soundMoney);
            isBuilt = false;
            GameManager.countTower -= 1;
            if (config is SupportTowerData)
            {
                RemoveAllBuffs();
            }
            if (towerActiveInMenu == this)
            {
                setGameObjectUpDeleStatus(false);
            }
            Destroy(gameObject);
            return;
        }
        if (towerActiveInMenu == this)
        {
            refreshButtonUpdate();
            if (Input.GetKeyDown(shortCuts.keyToSellTower))
            {
                // Simulamos que el jugador ha hecho clic en el botón de vender de ESTA torre
                deletetower.onClickPlayer();
            }
        }
        if (!isBuilt) return;
        UpdateTarget();
        DrawRangeCircleInGame();

        if (EnemyTimeStopAbility.IsTimeStopped) return;

        if (config is LaserTowerData)
            HandleLaserAttack();
        else if (config is ProjectileTowerData)
            HandleProjectileAttack();
        else if (config is SupportTowerData)
            HandleIncreaseDamage();
    }
    private void HandleLaserAttack()
    {
        LineRenderer lightningLase = null;
        Transform laserObj = transform.Find("towerInfernalLineRender");
        if (laserObj != null) lightningLase = laserObj.GetComponent<LineRenderer>();

        if (lightningLase == null) return;

        if (!isOverheated)
        {
            if (currentTarget != null)
            {
                lightningLase.enabled = true;
                lightningLase.positionCount = 2;
                lightningLase.SetPosition(0, transform.position);
                lightningLase.SetPosition(1, currentTarget.position);

                // Gasta batería
                laserActiveTimer -= Time.deltaTime;

                // Daño
                damageAccrued += currentDamage * Time.deltaTime;
                if (damageAccrued >= 1f)
                {
                    int dmg = Mathf.FloorToInt(damageAccrued);
                    currentTarget.GetComponent<Enemy>().TakeDamage(dmg);
                    damageAccrued -= dmg;
                }

                if (laserActiveTimer <= 0)
                {
                    isOverheated = true;
                    laserRestTimer = currentRestDuration;
                    lightningLase.enabled = false;
                }
            }
            else { lightningLase.enabled = false; }
        }
        else
        {
            // Descansando
            lightningLase.enabled = false;
            laserRestTimer -= Time.deltaTime;
            if (laserRestTimer <= 0)
            {
                isOverheated = false;
                laserActiveTimer = ((LaserTowerData)config).onTime;
            }
        }
    }
    private void HandleIncreaseDamage()
    {
        fireTimer -= Time.deltaTime;
        if (fireTimer <= 0f)
        {

            fireTimer = fireCooldown * GameManager.globalAttackSpeedMultiplier;
            float radius = attackRadius * GameManager.globalRadiusMultiplier;
            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, radius);

            foreach (Collider2D hit in hits)
            {
                if (hit.CompareTag("tower"))
                {
                    Tower nearbyTower = hit.GetComponent<Tower>();
                    if (nearbyTower != null && nearbyTower != this && nearbyTower.isBuilt && !buffedTowers.Contains(nearbyTower))
                    {
                        // Le damos el bufo y la apuntamos en la libreta
                        nearbyTower.currentDamage += currentIncreaseDamage;
                        buffedTowers.Add(nearbyTower);
                    }
                }
            }
        }
    }
    private void HandleProjectileAttack()
    {
        if (currentTarget == null) return;
        fireTimer -= Time.deltaTime;
        if (fireTimer <= 0)
        {
            Shoot();
            fireTimer = fireCooldown * GameManager.globalAttackSpeedMultiplier;
        }
    }
    /// <summary>
    /// Se ejecuta al hacer clic sobre la torre. Muestra el menú global de la interfaz 
    /// y "formatea" los botones para que apunten a las funciones de ESTA torre específica.
    /// </summary>
    public void OnMouseDown()
    {
        if (GameManager.currentState != GameState.Playing) return;

        towerActiveInMenu = this;
        setGameObjectUpDeleStatus(true);
        constructionMenu.cancelFunction();
        assignInformationImage();
        assignInformationText();

        // 1. Preparamos las variables
        Button btnDelete = null;
        Button btnCancel = null;

        // 2. Buscamos TODOS los botones que haya dentro del menú (el 'true' incluye los apagados)
        Button[] todosLosBotones = gameObjectUpdateDeleteTower.GetComponentsInChildren<Button>(true);

        // 3. Los asignamos por su nombre exacto
        foreach (Button btn in todosLosBotones)
        {
            if (btn.gameObject.name == "ButtonDeleteTower") btnDelete = btn;
            if (btn.gameObject.name == "ButtonCancelTower") btnCancel = btn;
        }

        // --- Comprobación de seguridad por si te has equivocado en algún nombre en Unity ---
        if (btnDelete == null || btnCancel == null)
        {
            Debug.LogError("¡Cuidado Jefe! No encuentro algún botón. Revisa que se llamen EXACTAMENTE ButtonDeleteTower y ButtonCancelTower en la jerarquía.");
            return;
        }
        int goldRecovered = Mathf.RoundToInt(totalGoldInvested * 0.75f);
        // --- Asignamos cuanto dinero recuperaria si vende ---
        btnDelete.GetComponentInChildren<TextMeshProUGUI>().text = "VENDER (Recuperas: " + goldRecovered + ")";
        // 5. ¡LA MAGIA! Limpiamos la memoria de los botones para que olviden otras torres
        btnDelete.onClick.RemoveAllListeners();
        btnCancel.onClick.RemoveAllListeners();

        // 6. Añadimos las funciones de ESTA torre en concreto
        btnDelete.onClick.AddListener(() => deletetower.onClickPlayer());
        btnCancel.onClick.AddListener(() => setGameObjectUpDeleStatus(false));
    }
    /// <summary>
    /// Enciende o apaga todos los elementos hijos del menú global de la torre en la interfaz (UI).
    /// </summary>
    public static void setGameObjectUpDeleStatus(bool status)
    {
        foreach (Transform hijo in gameObjectUpdateDeleteTower.transform)
        {
            hijo.gameObject.SetActive(status);
        }
        if (!status)
            towerActiveInMenu = null;
    }
    /// <summary>
    /// Busca enemigos dentro del radio y elige al que más adelantado va en el camino.
    /// </summary>
    private void UpdateTarget()
    {
        float realRadius = attackRadius * GameManager.globalRadiusMultiplier;
        // 1. COMPROBAR EL OBJETIVO FIJADO
        if (currentTarget != null)
        {
            Enemy currentEnemyScript = currentTarget.GetComponent<Enemy>();
            if (currentEnemyScript == null)
            {
                currentTarget = null;
            }
            else
            {
                float distanceToCurrent = Vector2.Distance(transform.position, currentEnemyScript.transform.position);
                // Margen de tolerancia para cuando el jugador esta en el limite
                float dropRadius = realRadius + 0.5f;
                // Si está apagado, muerto, o se ha salido del círculo rojo...
                if (!currentTarget.gameObject.activeInHierarchy || currentEnemyScript.IsDead || distanceToCurrent > dropRadius)
                {
                    currentTarget = null; // ...lo soltamos.
                }
                else
                {
                    return;
                }
            }

        }
        // 2. BUSCAR UN NUEVO OBJETIVO
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        float bestProgress = -Mathf.Infinity;
        GameObject bestEnemy = null;

        foreach (GameObject enemy in enemies)
        {
            if (!enemy.activeInHierarchy) continue;

            float distanceToEnemy = Vector2.Distance(transform.position, enemy.transform.position);

            if (distanceToEnemy <= realRadius)
            {
                Enemy enemyScript = enemy.GetComponent<Enemy>();

                if (enemyScript != null)
                {
                    if (enemyScript.IsDead) continue;

                    float progress = enemyScript.GetPathProgress();

                    if (progress > bestProgress)
                    {
                        bestProgress = progress;
                        bestEnemy = enemy;
                    }
                }
            }
        }

        currentTarget = bestEnemy != null ? bestEnemy.transform : null;
    }
    public void refreshButtonUpdate()
    {
        Button btnUpdate = null;
        // Buscamos TODOS los botones que haya dentro del menú (el 'true' incluye los apagados)
        Button[] todosLosBotones = gameObjectUpdateDeleteTower.GetComponentsInChildren<Button>(true);
        foreach (Button btn in todosLosBotones)
        {
            if (btn.gameObject.name == "ButtonUpdateTower") btnUpdate = btn;
        }
        if (btnUpdate == null)
        {
            Debug.LogError("¡Cuidado Jefe! No encuentro algún botón. Revisa que se llamen EXACTAMENTE ButtonUpdateTower en la jerarquía.");
            return;
        }
        // 1. Si la torre ya está al NIVEL MÁXIMO, aquí sí ocultamos el botón por completo.
        if (updatetower.levelOfTower >= 2)
        {
            btnUpdate.gameObject.SetActive(false);
            return; // Salimos de la función, no hay nada más que hacer
        }
        // 2. Si NO es nivel máximo, el botón SIEMPRE debe estar visible en pantalla.
        btnUpdate.gameObject.SetActive(true);
        int indexToLook = !isBuilt ? 0 : updatetower.levelOfTower + 1;
        float costTower = config.upgradeCosts[indexToLook];

        TextMeshProUGUI textBoton = btnUpdate.GetComponentInChildren<TextMeshProUGUI>();

        // 3. Comprobamos la cartera del jugador
        if (GameManager.countMoney >= costTower * GameManager.globalCostMultiplier)
        {
            // TIENE DINERO: Botón clicable, coste en verde
            btnUpdate.interactable = true;
            textBoton.text = "MEJORAR\n(Coste: <color=#2ECC71>" + (costTower * GameManager.globalCostMultiplier) + "</color>)";

            btnUpdate.onClick.RemoveAllListeners();
            btnUpdate.onClick.AddListener(() => updatetower.onClickPlayer());
        }
        else
        {
            // NO TIENE DINERO: Botón bloqueado (gris), coste en rojo
            btnUpdate.interactable = false;
            textBoton.text = "MEJORAR\n(Coste: <color=#E74C3C>" + (costTower * GameManager.globalCostMultiplier) + "</color>)";

            // Quitamos los listeners por seguridad
            btnUpdate.onClick.RemoveAllListeners();
        }
    }
    /// <summary>
    /// Instancia un proyectil en la posición actual de la torre y le asigna
    /// el objetivo fijado. Si la mejora de fuego está activa, añade quemadura
    /// al proyectil con la probabilidad global configurada.
    /// </summary>
    private void Shoot()
    {
        Vector3 startPos = transform.position;
        GameObject projectileGO = Instantiate(projectilePrefab, startPos, Quaternion.identity);

        Projectile projectile = projectileGO.GetComponent<Projectile>();
        if (projectile != null)
        {
            projectile.Seek(currentTarget);
            projectile.SetDamage(GetRealDamage(currentDamage));
            TryInjectBurnEffect(projectile);
            TryInjectPoisonEffect(projectile);
        }
    }

    /// <summary>
    /// Si la probabilidad global de quemadura es mayor que 0, lanza el dado
    /// y, en caso de éxito, construye un BurnOnHitEffect y se lo asigna
    /// al proyectil.
    ///
    /// Los parámetros de la quemadura (daño, intervalo, ticks) están aquí
    /// centralizados como constantes privadas. Si en el futuro se quiere
    /// exponerlos al inspector, basta moverlos a campos serializables sin
    /// tocar el resto del código.
    /// </summary>
    private void TryInjectBurnEffect(Projectile projectile)
    {
        if (GameManager.globalBurnProbability <= 0f) return;

        bool burnTriggered = Random.value < GameManager.globalBurnProbability;
        if (!burnTriggered) return;

        const int   burnDamagePerTick = 3;
        const float burnTickInterval  = 0.5f;
        const int   burnTotalTicks    = 12;   // duración total: 3 segundos

        projectile.AddOnHitEffect(new BurnOnHitEffect(
            burnDamagePerTick,
            burnTickInterval,
            burnTotalTicks
        ));
    }

    /// <summary>
    /// Si la probabilidad global de veneno es mayor que 0, lanza el dado
    /// y, en caso de éxito, construye un PoisonOnHitEffect y lo añade
    /// al proyectil. El veneno es apilable: cada impacto incrementa el daño.
    /// </summary>
    private void TryInjectPoisonEffect(Projectile projectile)
    {
        if (GameManager.globalPoisonProbability <= 0f) return;

        bool poisonTriggered = Random.value < GameManager.globalPoisonProbability;
        if (!poisonTriggered) return;

        const int   poisonBaseDamagePerTick = 1;   // daño base por tick (menor que fuego)
        const float poisonTickInterval      = 0.8f; // tick más lento que el fuego
        const int   poisonTotalTicks        = 10;   // duración total: 8 segundos
        const int   poisonMaxStacks         = 6;   // daño máximo: 6 × baseDamage por tick

        projectile.AddOnHitEffect(new PoisonOnHitEffect(
            poisonBaseDamagePerTick,
            poisonTickInterval,
            poisonTotalTicks,
            poisonMaxStacks
        ));
    }
    /// <summary>
    /// Configura la torre recién comprada o mejorada.
    /// </summary>
    public void SetTower(SpriteRenderer sprite = null, BoxCollider2D boxCollider = null, int type = 0)
    {
        SpriteRenderer spriteRenderer = this.GetComponent<SpriteRenderer>();

        // 1. Calculamos el nivel al que vamos y el coste
        int nextLevel = !isBuilt ? 0 : updatetower.levelOfTower + 1;
        int costTower = Mathf.RoundToInt(config.upgradeCosts[nextLevel] * GameManager.globalCostMultiplier);

        if (GameManager.countMoney >= costTower)
        {
            // 2. Cobramos y preparamos las variables
            setCountMoneyTotalGoldInvested(costTower);
            updateExtensionsTower();
            setTypeTower(type);

            // 3. Separamos Construir vs Mejorar para el orden de estadísticas
            if (!isBuilt)
            {
                // ES NUEVA (Nivel 0)
                isBuilt = true;
                updatetower.levelOfTower = 0;
                updateFireCooldownAndDamage(); // Ponemos la recarga base
                increaseCountTower();
            }
            else
            {
                // ES UNA MEJORA
                updatetower.levelOfTower++; // SUBIMOS EL NIVEL PRIMERO
                updateFireCooldownAndDamage(); // Como el nivel ya subió, ahora sí sumará el daño extra
            }

            // 4. Aplicamos los visuales
            if (sprite == null)
                sprite = towerImagen[0].GetComponent<SpriteRenderer>();
            if (boxCollider == null) boxCollider = towerImagen[0].GetComponent<BoxCollider2D>();
            setCollisionsAndSprite(spriteRenderer, sprite, boxCollider);

        }
        else
        {
            StartCoroutine(gameManager.messageError("No hay dinero suficiente"));
            GameManager.sound(GameManager.soundError);
        }
    }


    /// <summary>
    /// Dibuja el radio de ataque en color rojo en la vista de escena (Scene) 
    /// cuando la torre está seleccionada para ayudar visualmente en el diseño del nivel.
    /// </summary>
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
    /// <summary>
    /// Asigna el tipo de torre al script hijo encargado de gestionar las futuras mejoras.
    /// </summary>
    public void setTypeTower(int type)
    {
        updatetower.typeOfTower = type;
    }

    public void setCountMoneyTotalGoldInvested(int finalCost)
    {
        // 2. Se lo restamos al dinero del jugador
        GameManager.countMoney -= finalCost;

        // Feedback visual de gasto
        GameManager.ShowFloatingMoney(finalCost, isGain: false);
        GameManager.sound(GameManager.soundPay);

        // 3. ¡Lo guardamos en la hucha de la torre para su futura venta!
        totalGoldInvested += finalCost;
    }
    /// <summary>
    /// Activa los GameObjects internos de la torre que contienen los scripts de actualización y borrado.
    /// </summary>
    public void updateExtensionsTower()
    {
        deleteTowerGameObject.SetActive(true);
        updateTowerGameObject.SetActive(true);
    }
    /// <summary>
    /// Actualiza la apariencia física de la torre, aplicándole un nuevo sprite y ajustando 
    /// su caja de colisión (BoxCollider2D) al tamaño exacto de esa nueva imagen.
    /// </summary>
    public void setCollisionsAndSprite(SpriteRenderer spriteRenderer, SpriteRenderer spriteRenderNew, BoxCollider2D boxCollider)
    {
        spriteRenderer.sprite = spriteRenderNew.sprite;
        spriteRenderer.color = spriteRenderNew.color;
        this.GetComponent<BoxCollider2D>().size = new Vector2(boxCollider.size.x, boxCollider.size.y);

    }
    /// <summary>
    /// Suma/resta estadísticas en Nivel 1 y 2.
    /// </summary>
    public void updateFireCooldownAndDamage()
    {
        if (updatetower.levelOfTower == 0) return;

        RemoveAllBuffs();
        if (config is LaserTowerData || config is ProjectileTowerData)
        {
            currentDamage += upgradeDamageStep;
        }
        else if (config is SupportTowerData)
        {
            currentIncreaseDamage += upgradeDamageStep;
        }

        if (config is LaserTowerData)
        {
            // Mejora reduce el tiempo de espera de 2s
            currentRestDuration -= upgradeCooldownStep;
            currentRestDuration = Mathf.Max(currentRestDuration, 0.2f);
        }
        else
        {
            fireCooldown -= upgradeCooldownStep;
            fireCooldown = Mathf.Max(fireCooldown, 0.1f);
        }
    }
    /// <summary>
    /// Suma 1 al contador global de torres del GameManager, asegurándose de hacerlo 
    /// solo si es una torre recién construida (Nivel 0) y no una mejora.
    /// </summary>
    public void increaseCountTower()
    {
        if (updatetower.levelOfTower == 0)
        {
            GameManager.countTower += 1;
        }
    }
    /// <summary>
    /// Actualiza la imagen (sprite) mostrada en el panel de información, visualizando 
    /// cómo se verá la torre si el jugador decide mejorarla al siguiente nivel.
    /// Si ya está al máximo, muestra la imagen del nivel actual.
    /// </summary>
    public void assignInformationImage()
    {
        Image[] imageList = gameObjectUpdateDeleteTower.GetComponentsInChildren<Image>();
        foreach (Image image in imageList)
        {
            if (image.gameObject.name == "towerImageUpgrade")
            {
                if (updatetower.levelOfTower < 2)
                {
                    image.sprite = towerImagen[updatetower.levelOfTower + 1].GetComponent<SpriteRenderer>().sprite;
                    return;
                }
                image.sprite = towerImagen[updatetower.levelOfTower].GetComponent<SpriteRenderer>().sprite;
                return;
            }
        }
    }
    /// <summary>
    /// Actualiza los textos del panel de información (Nombre, Daño y Recarga).
    /// Calcula las estadísticas futuras de la torre y las muestra con etiquetas 
    /// de color verde para destacar que es una mejora positiva.
    /// </summary>
    public void assignInformationText()
    {
        TextMeshProUGUI[] textList = gameObjectUpdateDeleteTower.GetComponentsInChildren<TextMeshProUGUI>();
        foreach (TextMeshProUGUI text in textList)
        {
            if (text.name == "typeLevelText")
            {
                text.text = config.nameOfTower + " (Nivel " + (updatetower.levelOfTower + 1) + ")";
            }
            if (text.name == "currentDamageText")
            {
                damageFunction(text);
            }
            if (text.name == "cadenceText")
            {
                cadenceFunction(text);
            }
        }
    }
    /// <summary>
    /// Dibuja un círculo usando un LineRenderer para que EL JUGADOR lo vea en la pestaña Game.
    /// Es ultra-óptimo: solo se dibuja si está seleccionada, y solo se borra 1 vez cuando se deselecciona.
    /// </summary>
    public void DrawRangeCircleInGame()
    {
        if (lineRenderer == null) return;

        // Si esta torre NO es la que está seleccionada en el menú...
        if (towerActiveInMenu != this)
        {
            // Comprobamos si el LineRenderer tiene puntos. Si ya tiene 0, ignoramos todo y salimos.
            // Preguntar "cuánto vale un int" es gratis para el procesador, pero modificar un componente de Unity no lo es.
            if (lineRenderer.positionCount > 0)
            {
                lineRenderer.positionCount = 0; // Lo borramos solo una vez
            }
            return;
        }

        // --- SI LLEGA HASTA AQUÍ, ES PORQUE SÍ ESTÁ SELECCIONADA ---

        // El radio real con multiplicadores
        float realRadius = attackRadius * GameManager.globalRadiusMultiplier;

        // Le decimos al LineRenderer cuántos puntos va a tener la línea
        lineRenderer.positionCount = circleSegments;
        lineRenderer.useWorldSpace = false; // Para que siga a la torre si se mueve
        lineRenderer.loop = true; // Cierra el círculo perfectamente

        // Matemáticas para dibujar un círculo punto por punto
        float angle = 0f;
        for (int i = 0; i < circleSegments; i++)
        {
            float x = Mathf.Sin(Mathf.Deg2Rad * angle) * realRadius;
            float y = Mathf.Cos(Mathf.Deg2Rad * angle) * realRadius;

            // PONEMOS LA Z EN -1 PARA QUE NO SE ESCONDA DETRÁS DEL CÉSPED
            lineRenderer.SetPosition(i, new Vector3(x, y, -1f));

            angle += (360f / circleSegments);
        }
    }
    public void damageFunction(TextMeshProUGUI text)
    {
        // Si es torre de soporte, leemos el daño extra y cambiamos el texto
        if (config is SupportTowerData)
        {
            if (updatetower.levelOfTower < 2)
            {
                float increaseSupportDamage = currentIncreaseDamage + upgradeDamageStep;
                text.text = "Daño Extra: [" + currentIncreaseDamage.ToString("F1") + "] -> <color=#2ECC71> [" + increaseSupportDamage.ToString("F1") + "] </color>";
            }
            else
            {
                text.text = "Daño Extra: [" + currentIncreaseDamage.ToString("F1") + "] (MÁXIMO)";
            }
        }
        // Si es cualquier otra torre, usamos la lógica normal
        else
        {
            float realCurrentDamage = GetRealDamage(currentDamage);
            if (updatetower.levelOfTower < 2)
            {
                float increaseCurrentDamage = GetRealDamage(currentDamage + upgradeDamageStep);
                text.text = "Daño: [" + realCurrentDamage.ToString("F1") + "] -> <color=#2ECC71> [" + increaseCurrentDamage.ToString("F1") + "] </color>";
            }
            else
            {
                text.text = "Daño: [" + realCurrentDamage.ToString("F1") + "] (MÁXIMO)";
            }
        }
    }
    public void cadenceFunction(TextMeshProUGUI text)
    {
        if (config is LaserTowerData || config is ProjectileTowerData)
        {
            float currentBaseCooldown = config is LaserTowerData ? currentRestDuration : fireCooldown;
            if (updatetower.levelOfTower < 2)
            {
                // 1. Recarga REAL actual (Base * Cartas)
                float realCurrentCooldown = currentBaseCooldown * GameManager.globalAttackSpeedMultiplier;

                // 2. Simulamos cuál será la Base si la mejoramos
                float baseNextCooldown = currentBaseCooldown - upgradeCooldownStep;
                baseNextCooldown = Mathf.Max(baseNextCooldown, 0.1f); // Seguridad para la base

                // 3. Recarga REAL futura (Nueva Base * Cartas)
                float realNextCooldown = baseNextCooldown * GameManager.globalAttackSpeedMultiplier;
                realNextCooldown = Mathf.Max(realNextCooldown, 0.1f); // Seguridad final

                text.text = "Recarga: [" + realCurrentCooldown.ToString("F2") + "s] -> <color=#2ECC71>[" + realNextCooldown.ToString("F2") + "s] </color>";
            }
            else
            {
                // Si ya es nivel máximo, calculamos su recarga real actual para mostrarla
                float realCurrentCooldown = currentBaseCooldown * GameManager.globalAttackSpeedMultiplier;
                text.text = "Recarga: [" + realCurrentCooldown.ToString("F2") + "s] (MÁXIMO)";
            }
        }
        else
        {
            // --- LÓGICA PARA LA TORRE DE SOPORTE ---
            if (updatetower.levelOfTower < 2)
            {
                // Usamos fireCooldown (que en esta torre guarda el tiempo de escaneo)
                float realCurrentScan = fireCooldown * GameManager.globalAttackSpeedMultiplier;

                float baseNextScan = fireCooldown - upgradeCooldownStep;
                baseNextScan = Mathf.Max(baseNextScan, 0.1f);

                float realNextScan = baseNextScan * GameManager.globalAttackSpeedMultiplier;
                realNextScan = Mathf.Max(realNextScan, 0.1f);

                text.text = "Escaneo: [" + realCurrentScan.ToString("F2") + "s] -> <color=#2ECC71>[" + realNextScan.ToString("F2") + "s] </color>";
            }
            else
            {
                float realCurrentScan = fireCooldown * GameManager.globalAttackSpeedMultiplier;
                text.text = "Escaneo: [" + realCurrentScan.ToString("F2") + "s] (MÁXIMO)";
            }
        }
    }
    /// <summary>
    /// Elimina el daño extra otorgado a todas las torres aliadas que estaban siendo potenciadas.
    /// Recorre la lista de torres bufadas, resta la bonificación actual y vacía el registro.
    /// Es vital llamarlo antes de mejorar esta torre (para actualizar el bufo) o al destruirla/venderla.
    /// </summary>
    public void RemoveAllBuffs()
    {
        foreach (Tower tower in buffedTowers)
        {
            if (tower != null)
            {
                tower.currentDamage -= currentIncreaseDamage;
            }
        }
        buffedTowers.Clear();
    }

    /// <summary>
    /// Calcula el daño real aplicando los multiplicadores globales.
    /// </summary>
    public float GetRealDamage(float baseDamage)
    {
        return baseDamage * GameManager.globalDamageTakenMultiplier;
    }
}
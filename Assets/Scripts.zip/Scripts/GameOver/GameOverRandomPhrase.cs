using TMPro;
using UnityEngine;

public class GameOverRandomPhrase : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI phraseText;

    [TextArea(2, 4)]
    [SerializeField] private string[] phrases =
    {
        "El basti�n cay�, pero al menos lo intentaste.",
        "Los enemigos han pedido repetir la partida.",
        "El castillo resisti� menos que tus excusas.",
        "Derrota �pica. Estrategia cuestionable.",
        "Los enemigos agradecen tu generosidad.",
        "Los enemigos entraron como Pedro por su casa.",
        "No era un tower defense, era un tower suggestion.",
        "Tu estrategia ser� estudiada. Como advertencia.",
        "Buen intento. Los enemigos se rieron much�simo.",
        "Las murallas eran m�s emocionales que f�sicas.",
        "Has desbloqueado el rango: amenaza para el reino.",
        "Tus torres y t� hab�is decidido tomar caminos separados.",
        "El basti�n encontr� a alguien que s� sabe defenderlo.",
        "Tus murallas dijeron: 'no eres t�, soy yo'",
        "La conexi�n entre t� y el reino se perdi� hace varias rondas.",
        "El castillo ya ven�a viendo red flags desde la ronda 3.",
        "Tu estrategia fue un 'tenemos que hablar'",
        "�Madre m�a, qu� defensa m�s blandita!",
        "�Pero ci�rrale el paso hombre!"
    };

    private void Start()
    {
        if (phraseText == null)
            phraseText = GetComponent<TextMeshProUGUI>();

        if (phrases.Length > 0 && phraseText != null)
        {
            int randomIndex = Random.Range(0, phrases.Length);
            phraseText.text = phrases[randomIndex];
        }
    }
}